# -*- coding: utf-8 -*-

from .str_dict_func import str_dict
